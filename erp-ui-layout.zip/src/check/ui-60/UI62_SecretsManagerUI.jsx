import React, { useEffect, useMemo, useState } from "react";

export default function UI62_SecretsManagerUI() {
  const [query, setQuery] = useState("");
  const initialSecrets = useMemo(
    () => [
      { id: "s-2001", name: "db/password", type: "credential", environment: "prod", owner: "infra-team", createdAt: "2025-06-10" },
      { id: "s-2002", name: "api/key/payment", type: "api-key", environment: "staging", owner: "payments", createdAt: "2025-07-15" },
      { id: "s-2003", name: "oauth/client_secret", type: "credential", environment: "prod", owner: "auth", createdAt: "2025-08-01" },
      { id: "s-2004", name: "smtp/password", type: "credential", environment: "dev", owner: "comm", createdAt: "2025-08-12" },
    ],
    []
  );

  const [secrets, setSecrets] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [selectedIds, setSelectedIds] = useState(new Set());

  const mockFetch = () => new Promise((resolve, reject) => setTimeout(() => resolve(initialSecrets), 450));

  const fetchSecrets = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await mockFetch();
      setSecrets(Array.isArray(data) ? data : []);
      setSelectedIds(new Set());
    } catch (err) {
      setError(err?.message || "Failed to load secrets");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchSecrets(); }, []);

  const filtered = secrets.filter((s) => {
    if (!query) return true;
    const q = query.toLowerCase();
    return s.name.toLowerCase().includes(q) || s.id.toLowerCase().includes(q) || s.owner.toLowerCase().includes(q) || s.environment.toLowerCase().includes(q);
  });

  const toggleSelect = (id) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const selectAllVisible = () => {
    setSelectedIds(new Set(filtered.map((s) => s.id)));
  };
  const clearSelection = () => setSelectedIds(new Set());

  const exportJSON = (payload, filename = "secrets_export.json") => {
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  const exportSelected = () => {
    const selected = secrets.filter((s) => selectedIds.has(s.id));
    exportJSON({ exportedAt: new Date().toISOString(), count: selected.length, secrets: selected }, `secrets_selected_${new Date().toISOString()}.json`);
  };

  const exportAll = () => {
    exportJSON({ exportedAt: new Date().toISOString(), count: secrets.length, secrets }, `secrets_all_${new Date().toISOString()}.json`);
  };

  return (
    <div className="p-6">
      <header className="mb-4">
        <h1 className="text-2xl font-bold">UI62 — Secrets Manager UI (Mock)</h1>
        <p className="mt-1 text-gray-600">Mock interface for viewing secret metadata. Do not store real secrets here.</p>
      </header>

      <div className="p-4 mb-4 bg-white rounded shadow-sm">
        <div className="flex items-center gap-3 mb-3">
          <input
            className="flex-1 p-2 border rounded"
            placeholder="Search by name, id, owner, or environment"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />

          <div className="flex gap-2">
            <button onClick={fetchSecrets} className="px-3 py-1 bg-gray-100 rounded">Refresh</button>
            <button onClick={selectAllVisible} className="px-3 py-1 bg-gray-100 rounded">Select visible</button>
            <button onClick={clearSelection} className="px-3 py-1 bg-gray-100 rounded">Clear selection</button>
            <button onClick={exportSelected} className="px-3 py-1 text-white bg-blue-600 rounded">Export selected</button>
            <button onClick={exportAll} className="px-3 py-1 bg-gray-100 rounded">Export all</button>
          </div>
        </div>

        {loading ? (
          <div className="text-gray-500">Loading…</div>
        ) : error ? (
          <div className="text-xs text-red-500">{error}</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead>
                <tr className="text-xs text-gray-500">
                  <th className="p-2"><input type="checkbox" checked={filtered.length > 0 && filtered.every(s => selectedIds.has(s.id))} onChange={(e) => e.target.checked ? selectAllVisible() : clearSelection()} /></th>
                  <th className="p-2">ID</th>
                  <th className="p-2">Name</th>
                  <th className="p-2">Type</th>
                  <th className="p-2">Environment</th>
                  <th className="p-2">Owner</th>
                  <th className="p-2">Created</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((s) => (
                  <tr key={s.id} className="border-t hover:bg-gray-50">
                    <td className="p-2"><input type="checkbox" checked={selectedIds.has(s.id)} onChange={() => toggleSelect(s.id)} /></td>
                    <td className="p-2">{s.id}</td>
                    <td className="p-2">{s.name}</td>
                    <td className="p-2">{s.type}</td>
                    <td className="p-2">{s.environment}</td>
                    <td className="p-2">{s.owner}</td>
                    <td className="p-2">{s.createdAt}</td>
                  </tr>
                ))}

                {filtered.length === 0 && (
                  <tr>
                    <td colSpan={7} className="p-4 text-gray-500">No secrets match the current filter.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <div className="text-xs text-gray-500">
        Note: This is a mock viewer for metadata only. Secrets values are intentionally omitted.
      </div>
    </div>
  );
}
